package dual;

import java.util.ArrayList;
import java.util.Currency;

public class Reservacion {
	private int precioTotal;

    private Agencia agencia;

    private Cliente cliente;

    private ArrayList<Coche> reservacion;
    
	public int getPrecioTotal() {
		return precioTotal;
	}

	public void setPrecioTotal(int precioTotal) {
		this.precioTotal = precioTotal;
	}

	public Reservacion(int precioTotal) {
		super();
		this.precioTotal = precioTotal;
	}
	
	
}
