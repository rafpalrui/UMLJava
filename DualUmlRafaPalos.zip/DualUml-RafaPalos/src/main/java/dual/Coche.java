package dual;

import java.util.ArrayList;
import java.util.Currency;

public class Coche {
	private int precio;
	private boolean cocheDisponible;
	private String matricula, marca, modelo, color;
	
    private ArrayList<Reservacion> coche;
    private Garaje garaje;
    
	public int getPrecio() {
		return precio;
	}
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	public boolean isCocheDisponible() {
		return cocheDisponible;
	}
	public void setCocheDisponible(boolean cocheDisponible) {
		this.cocheDisponible = cocheDisponible;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	public Coche(int precio, boolean cocheDisponible, String matricula, String marca, String modelo,
			String color) {
		super();
		this.precio = precio;
		this.cocheDisponible = cocheDisponible;
		this.matricula = matricula;
		this.marca = marca;
		this.modelo = modelo;
		this.color = color;
	}
	
	
}
