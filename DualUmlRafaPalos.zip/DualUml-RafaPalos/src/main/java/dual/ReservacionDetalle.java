package dual;

import java.util.ArrayList;
import java.util.Date;

public class ReservacionDetalle {
	private String fechaInicio, fechaFinal;
	private int gasolina;
    private ArrayList<Reservacion> reservacionDetalle1;
    private ArrayList<Coche> reservacionDetalle2;
    
	public String getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public String getFechaFinal() {
		return fechaFinal;
	}
	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}
	public int getGasolina() {
		return gasolina;
	}
	public void setGasolina(int gasolina) {
		this.gasolina = gasolina;
	}
	
	public ReservacionDetalle(String fechaInicio, String fechaFinal, int gasolina) {
		super();
		this.fechaInicio = fechaInicio;
		this.fechaFinal = fechaFinal;
		this.gasolina = gasolina;
	}
}
