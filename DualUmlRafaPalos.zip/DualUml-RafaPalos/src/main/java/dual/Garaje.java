package dual;

import java.util.ArrayList;

public class Garaje {
	private String codigo;
	private int cantidadMaxCoches;
	private ArrayList<Coche> garaje;
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public int getCantidadMaxCoches() {
		return cantidadMaxCoches;
	}
	public void setCantidadMaxCoches(int cantidadMaxCoches) {
		this.cantidadMaxCoches = cantidadMaxCoches;
	}
	
	public Garaje(String codigo, int cantidadMaxCoches) {
		super();
		this.codigo = codigo;
		this.cantidadMaxCoches = cantidadMaxCoches;
	}
	
	
}
